import 'package:supabase_flutter/supabase_flutter.dart';
import './supabase_service.dart';
import '../models/event_attendance_model.dart';

class EventService {
  static Future<Map<String, dynamic>> createSimpleEvent({
    required String title,
    required String description,
    required DateTime dateTime,
    required String location,
  }) async {
    try {
      final userId = SupabaseService.client.auth.currentUser!.id;

      print('Creating event for user: $userId');
      print('Event data: $title, $description, $dateTime, $location');

      final response = await SupabaseService.client
          .from('events')
          .insert({
        'title': title,
        'description': description,
        'date_time': dateTime.toIso8601String(),
        'location': location,
        'organizer_id': userId,
        'status': 'scheduled',
        'min_attendance': 5,
      })
          .select()
          .single();

      print('Event created successfully: $response');
      return response;

    } catch (e) {
      print('DETAILED ERROR creating event: $e');

      if (e.toString().contains('foreign key')) {
        throw Exception('Организатор не найден в системе. User ID: ${SupabaseService.client.auth.currentUser!.id}');
      } else if (e.toString().contains('null value')) {
        throw Exception('Обязательные поля не заполнены');
      } else if (e.toString().contains('network') || e.toString().contains('SocketException')) {
        throw Exception('Проблема с интернет-соединением');
      } else {
        throw Exception('Ошибка базы данных: $e');
      }
    }
  }

  // Метод для получения количества подтвердивших участие
  static Future<int> getConfirmedCount(String eventId) async {
    try {
      final response = await SupabaseService.client
          .from('event_invitations')
          .select()
          .eq('event_id', eventId)
          .eq('status', 'confirmed');

      return response.length;
    } catch (e) {
      print('Error getting confirmed count: $e');
      return 0;
    }
  }

  // Упрощенный поток для реального времени - переименовал метод
  static Stream<List<Map<String, dynamic>>> getInvitationsStream() {
    return SupabaseService.client
        .from('event_invitations')
        .stream(primaryKey: ['id'])
        .order('created_at', ascending: false);
  }

  static Future<List<Map<String, dynamic>>> getSimpleEvents() async {
    try {
      final response = await SupabaseService.client
          .from('events')
          .select('*')
          .order('date_time', ascending: true);

      return (response as List).cast<Map<String, dynamic>>();
    } catch (e) {
      print('Error fetching events: $e');
      return [];
    }
  }

  static Future<List<Event>> getEvents() async {
    try {
      final response = await SupabaseService.client
          .from('events')
          .select('''
            *,
            organizer:users(name),
            invitations:event_invitations(
              user_id,
              status,
              user:users(name, role)
            )
          ''')
          .order('date_time', ascending: true);

      return (response as List).map((json) => Event.fromJson(json)).toList();
    } catch (e) {
      print('Error fetching events: $e');
      return [];
    }
  }

  static Future<void> confirmAttendance(String eventId, String status) async {
    try {
      final userId = SupabaseService.client.auth.currentUser!.id;

      await SupabaseService.client
          .from('event_invitations')
          .upsert({
        'event_id': eventId,
        'user_id': userId,
        'status': status,
        'response_date': DateTime.now().toIso8601String(),
      });

    } catch (e) {
      print('Error confirming attendance: $e');
      throw e;
    }
  }

  static Future<AttendanceReport> getEventAttendanceReport(String eventId) async {
    try {
      final event = await SupabaseService.client
          .from('events')
          .select()
          .eq('id', eventId)
          .single();

      final attendances = await SupabaseService.client
          .from('event_invitations')
          .select('''
            *,
            user:users(name, role)
          ''')
          .eq('event_id', eventId);

      final eventObj = Event.fromJson(event);
      final attendanceList = (attendances as List)
          .map((json) => EventAttendance.fromJson(json))
          .toList();

      return AttendanceReport.generateFromEvent(eventObj, attendanceList);
    } catch (e) {
      print('Error fetching attendance report: $e');
      throw e;
    }
  }

  static Stream<List<Map<String, dynamic>>> getEventsStream() {
    return SupabaseService.client
        .from('events')
        .stream(primaryKey: ['id'])
        .order('date_time', ascending: true);
  }

  static Future<Map<String, dynamic>> createEvent({
    required String title,
    required String description,
    required DateTime dateTime,
    required String location,
  }) async {
    try {
      final userId = SupabaseService.client.auth.currentUser!.id;

      final response = await SupabaseService.client
          .from('events')
          .insert({
        'title': title,
        'description': description,
        'date_time': dateTime.toIso8601String(),
        'location': location,
        'organizer_id': userId,
        'status': 'scheduled',
        'min_attendance': 5,
      })
          .select()
          .single();

      return response;
    } catch (e) {
      print('Error creating event: $e');

      if (e.toString().contains('foreign key')) {
        throw Exception('Ошибка: Пользователь не найден в системе');
      } else if (e.toString().contains('null value')) {
        throw Exception('Ошибка: Обязательные поля не заполнены');
      } else {
        throw Exception('Ошибка создания мероприятия: $e');
      }
    }
  }

  static Future<List<Event>> getUserEvents() async {
    try {
      final userId = SupabaseService.client.auth.currentUser!.id;

      final response = await SupabaseService.client
          .from('event_invitations')
          .select('''
            event:events(
              *,
              organizer:users(name),
              invitations:event_invitations(
                user_id,
                status,
                user:users(name, role)
              )
            )
          ''')
          .eq('user_id', userId)
          .order('event(date_time)', ascending: true);

      return (response as List)
          .map((json) => Event.fromJson(json['event']))
          .toList();
    } catch (e) {
      print('Error fetching user events: $e');
      return [];
    }
  }

  static Future<List<Event>> getEventsByOrganizer(String organizerId) async {
    try {
      final response = await SupabaseService.client
          .from('events')
          .select('''
            *,
            organizer:users(name),
            invitations:event_invitations(
              user_id,
              status,
              user:users(name, role)
            )
          ''')
          .eq('organizer_id', organizerId)
          .order('date_time', ascending: true);

      return (response as List).map((json) => Event.fromJson(json)).toList();
    } catch (e) {
      print('Error fetching organizer events: $e');
      return [];
    }
  }
}