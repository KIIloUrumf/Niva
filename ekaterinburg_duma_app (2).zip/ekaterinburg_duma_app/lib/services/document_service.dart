import 'package:supabase_flutter/supabase_flutter.dart';
import './supabase_service.dart';
import '../models/document_model.dart';

class DocumentService {
  static Future<List<DocumentCategory>> getDocumentCategories() async {
    try {
      final response = await SupabaseService.client
          .from('document_categories')
          .select()
          .order('name');

      return (response as List).map((json) => DocumentCategory.fromJson(json)).toList();
    } catch (e) {
      print('Error fetching categories: $e');
      return [];
    }
  }

  static Future<List<Document>> getDocumentsByCategory(String categoryId) async {
    try {
      final response = await SupabaseService.client
          .from('documents')
          .select('''
            *,
            uploaded_by:users(name)
          ''')
          .eq('category_id', categoryId)
          .order('upload_date', ascending: false);

      return (response as List).map((json) => Document.fromJson(json)).toList();
    } catch (e) {
      print('Error fetching documents: $e');
      return [];
    }
  }

  static Future<void> downloadDocument(Document document) async {
    try {
      final response = await SupabaseService.client.storage
          .from('documents')
          .download(document.fileName);
      print('Document downloaded: ${document.fileName}');
    } catch (e) {
      print('Error downloading document: $e');
    }
  }

  static Future<Map<String, dynamic>> getDocumentStats() async {
    try {
      final documentsResponse = await SupabaseService.client
          .from('documents')
          .select();

      final documents = documentsResponse as List;
      final totalSize = documents.fold<int>(0, (sum, item) => sum + (item['file_size'] as int));

      return {
        'total_documents': documents.length,
        'total_size': '${(totalSize / 1048576).toStringAsFixed(1)} МБ',
        'most_active_category': 'Протоколы заседаний',
        'recent_uploads': 5,
      };
    } catch (e) {
      print('Error fetching stats: $e');
      return {
        'total_documents': 0,
        'total_size': '0 МБ',
        'most_active_category': 'Нет данных',
        'recent_uploads': 0,
      };
    }
  }
}