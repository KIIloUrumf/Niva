import 'dart:convert';
import 'dart:math';

class SecurityService {
  // Базовое шифрование для демо
  static String _encrypt(String text) {
    final key = _generateKey();
    final bytes = utf8.encode(text);
    final encrypted = _xorEncrypt(bytes, key);
    return base64.encode(encrypted);
  }

  static String _decrypt(String encryptedText) {
    final key = _generateKey();
    final bytes = base64.decode(encryptedText);
    final decrypted = _xorEncrypt(bytes, key);
    return utf8.decode(decrypted);
  }

  static List<int> _xorEncrypt(List<int> bytes, List<int> key) {
    final result = <int>[];
    for (int i = 0; i < bytes.length; i++) {
      result.add(bytes[i] ^ key[i % key.length]);
    }
    return result;
  }

  static List<int> _generateKey() {
    return utf8.encode('duma_ekb_secure_key_2025');
  }

  // Хеширование паролей
  static String hashPassword(String password) {
    final salt = 'duma_ekb_salt_2025';
    final bytes = utf8.encode(password + salt);
    final hash = _simpleHash(bytes);
    return base64.encode(hash);
  }

  static List<int> _simpleHash(List<int> input) {
    var hash = 0;
    for (final byte in input) {
      hash = (hash << 5) - hash + byte;
      hash = hash & hash;
    }
    return [hash >> 24, (hash >> 16) & 0xFF, (hash >> 8) & 0xFF, hash & 0xFF];
  }

  // Валидация email
  static bool isValidEmail(String email) {
    final regex = RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
    return regex.hasMatch(email) &&
        email.length <= 100 &&
        !email.contains('..') &&
        !email.contains('--');
  }

  // Валидация пароля (упрощенная для демо)
  static bool isValidPassword(String password) {
    return password.length >= 6; // Упростил для демо
    // Полная версия:
    // return password.length >= 8 &&
    //        password.length <= 128 &&
    //        RegExp(r'[A-Z]').hasMatch(password) &&
    //        RegExp(r'[a-z]').hasMatch(password) &&
    //        RegExp(r'[0-9]').hasMatch(password) &&
    //        RegExp(r'[!@#$%^&*(),.?":{}|<>]').hasMatch(password);
  }

  // Очистка входных данных
  static String sanitizeInput(String input) {
    return input
        .replaceAll(RegExp(r'[<>"/\\&]'), '')
        .trim()
        .substring(0, min(input.length, 1000));
  }

  // Генерация токена
  static String generateSecureToken() {
    final random = Random.secure();
    final values = List<int>.generate(32, (i) => random.nextInt(256));
    return base64Url.encode(values);
  }

  // Логирование security events
  static void logSecurityEvent(String event, String userEmail, {String details = ''}) {
    final timestamp = DateTime.now().toIso8601String();
    print('SECURITY_EVENT: $timestamp | $event | User: $userEmail | Details: $details');
  }
}

// Отдельный класс для управления попытками входа
class LoginAttempts {
  static final Map<String, int> _attempts = {};
  static final Map<String, DateTime> _lockouts = {};

  static bool isAccountLocked(String email) {
    final lockoutTime = _lockouts[email];
    if (lockoutTime != null) {
      if (DateTime.now().difference(lockoutTime).inMinutes < 30) {
        return true;
      } else {
        _lockouts.remove(email);
        _attempts.remove(email);
      }
    }
    return false;
  }

  static void recordFailedAttempt(String email) {
    _attempts[email] = (_attempts[email] ?? 0) + 1;

    if (_attempts[email]! >= 5) {
      _lockouts[email] = DateTime.now();
      SecurityService.logSecurityEvent('ACCOUNT_LOCKOUT', email, details: 'Too many failed attempts');
    }
  }

  static void resetAttempts(String email) {
    _attempts.remove(email);
    _lockouts.remove(email);
  }
}