import 'package:supabase_flutter/supabase_flutter.dart';
import './supabase_service.dart';

class AuthService {
  // УБЕРИТЕ эти поля - они не нужны в статическом классе
  // final SupabaseClient client;
  // AuthService(this.client);
  // static AuthService get instance => AuthService(SupabaseService.client);

  // Основной метод логина (статический)
  static Future<Map<String, dynamic>?> login(String email, String password) async {
    try {
      // Используйте SupabaseService.client напрямую
      final response = await SupabaseService.client.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (response.user != null) {
        // Получаем данные пользователя из таблицы users
        final userData = await SupabaseService.client
            .from('users')
            .select()
            .eq('id', response.user!.id)
            .single();

        // ПРОВЕРЯЕМ АКТИВНОСТЬ ПОЛЬЗОВАТЕЛЯ
        if (userData['is_active'] != true) {
          await SupabaseService.client.auth.signOut();
          throw Exception('Аккаунт деактивирован. Обратитесь к администратору.');
        }

        // Обновляем last_login
        await SupabaseService.client
            .from('users')
            .update({'last_login': DateTime.now().toIso8601String()})
            .eq('id', response.user!.id);

        return userData;
      }
      return null;
    } catch (e) {
      print('Login error: $e');

      // Обрабатываем ошибку деактивированного аккаунта
      if (e.toString().contains('деактивирован')) {
        rethrow;
      }

      return null;
    }
  }

  static Future<void> logout() async {
    await SupabaseService.client.auth.signOut();
  }

  static User? get currentUser {
    return SupabaseService.client.auth.currentUser;
  }

  static String? get token {
    return SupabaseService.client.auth.currentSession?.accessToken;
  }

  static Future<void> resetPassword(String email) async {
    await SupabaseService.client.auth.resetPasswordForEmail(email);
  }

  // Метод для создания пользователя (для админа)
  static Future<Map<String, dynamic>?> createUser({
    required String email,
    required String password,
    required String name,
    required String role,
    String? position,
    String? department,
    List<String> permissions = const [],
  }) async {
    try {
      // Создаем пользователя в Auth
      final authResponse = await SupabaseService.client.auth.admin.createUser(
        AdminUserAttributes(
          email: email,
          password: password,
          emailConfirm: true,
        ),
      );

      if (authResponse.user != null) {
        // Добавляем в таблицу users
        final userData = {
          'id': authResponse.user!.id,
          'email': email,
          'name': name,
          'role': role,
          'position': position ?? _getDefaultPosition(role),
          'department': department ?? _getDefaultDepartment(role),
          'permissions': permissions.isNotEmpty ? permissions : _getDefaultPermissions(role),
          'is_active': true,
        };

        await SupabaseService.client.from('users').insert(userData);

        return userData;
      }
      return null;
    } catch (e) {
      print('Create user error: $e');
      rethrow;
    }
  }

  // Вспомогательные методы для значений по умолчанию (тоже статические)
  static String _getDefaultPosition(String role) {
    switch (role) {
      case 'admin': return 'Администратор';
      case 'deputy': return 'Депутат';
      case 'staff': return 'Сотрудник аппарата';
      default: return 'Сотрудник';
    }
  }

  static String _getDefaultDepartment(String role) {
    switch (role) {
      case 'admin': return 'ИТ отдел';
      case 'deputy': return 'Комитет по бюджету';
      case 'staff': return 'Организационный отдел';
      default: return 'Отдел';
    }
  }

  static List<String> _getDefaultPermissions(String role) {
    switch (role) {
      case 'admin': return ['all'];
      case 'deputy': return ['events', 'documents', 'profile', 'meetings', 'feedback', 'attendance'];
      case 'staff': return ['documents', 'profile'];
      default: return ['documents', 'profile'];
    }
  }
}