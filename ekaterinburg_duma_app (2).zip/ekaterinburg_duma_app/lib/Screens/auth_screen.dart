import 'package:flutter/material.dart';
import 'main_menu_screen.dart';
import '../main.dart';
import '../services/security_service.dart';
import '../services/auth_service.dart';
import '../services/supabase_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;
  bool _obscurePassword = true;

  // Локальная база пользователей с захэшированными паролями
  final Map<String, Map<String, dynamic>> _users = {
    'admin@duma-ekb.ru': {
      'password': SecurityService.hashPassword('admin123'),
      'name': 'Администратор Системы',
      'role': 'admin',
      'position': 'Системный администратор',
      'email': 'admin@duma-ekb.ru',
      'phone': '+7 (343) 000-00-00',
      'department': 'ИТ отдел',
      'permissions': ['all'],
      'lastLogin': null,
      'isActive': true,
    },
    'deputy@duma-ekb.ru': {
      'password': SecurityService.hashPassword('deputy123'),
      'name': 'Иван Иванов',
      'role': 'deputy',
      'position': 'Депутат',
      'email': 'deputy@duma-ekb.ru',
      'phone': '+7 (343) 111-11-11',
      'department': 'Комитет по бюджету',
      'permissions': ['events', 'documents', 'profile', 'meetings', 'feedback', 'attendance'],
      'lastLogin': null,
      'isActive': true,
    },
    'staff@duma-ekb.ru': {
      'password': SecurityService.hashPassword('staff123'),
      'name': 'Петр Петров',
      'role': 'staff',
      'position': 'Сотрудник аппарата',
      'email': 'staff@duma-ekb.ru',
      'phone': '+7 (343) 222-22-22',
      'department': 'Организационный отдел',
      'permissions': ['documents', 'profile'],
      'lastLogin': null,
      'isActive': true,
    },
  };

  Map<String, dynamic>? _authenticate(String email, String password) {
    if (LoginAttempts.isAccountLocked(email)) {
      SecurityService.logSecurityEvent('LOGIN_ATTEMPT_LOCKED', email);
      return null;
    }

    if (!SecurityService.isValidEmail(email)) {
      SecurityService.logSecurityEvent('INVALID_EMAIL_FORMAT', email);
      return null;
    }

    final hashedPassword = SecurityService.hashPassword(password);

    if (_users.containsKey(email) &&
        _users[email]!['password'] == hashedPassword &&
        _users[email]!['isActive'] == true) {

      LoginAttempts.resetAttempts(email);
      _users[email]!['lastLogin'] = DateTime.now().toIso8601String();
      SecurityService.logSecurityEvent('LOGIN_SUCCESS', email);
      return _users[email];
    } else {
      LoginAttempts.recordFailedAttempt(email);
      SecurityService.logSecurityEvent('LOGIN_FAILED', email);
    }

    return null;
  }

  List<String> _getTestAccounts() {
    return _users.entries.map((entry) {
      final email = entry.key;
      final role = entry.value['role'] == 'admin' ? 'Админ' :
      entry.value['role'] == 'deputy' ? 'Депутат' : 'Сотрудник';
      return '$email ($role) / ${_getDemoPassword()}';
    }).toList();
  }

  String _getDemoPassword() {
    return 'admin123, deputy123, staff123';
  }

  void _login() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isLoading = true);

      print('=== DEBUG LOGIN ===');
      print('Email: ${_emailController.text}');
      print('Password: ${_passwordController.text}');

      try {
        print('Пытаемся войти через Supabase...');

        // ИСПРАВЬТЕ ЭТУ СТРОКУ - используйте статический метод:
        final userData = await AuthService.login(  // ← УБРАТЬ static если есть
          _emailController.text.trim(),
          _passwordController.text,
        );

        print('AuthService response: ${userData != null ? "SUCCESS" : "FAILED"}');

        if (userData != null) {
          print('✅ Аутентификация успешна! ID пользователя: ${userData['id']}');

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => MainMenuScreen(userData: userData)),
          );
        } else {
          print('❌ Ошибка аутентификации');
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Неверный email или пароль'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } catch (e) {
        print('💥 Ошибка входа: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ошибка входа: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }

      setState(() => _isLoading = false);
    }
  }

  void _showSecurityInfo() {
    showDialog(
      context: context,
      builder: (context) => Theme(
        data: Theme.of(context), // Используем текущую тему
        child: AlertDialog(
          title: const Text('Информация о безопасности'),
          content: const SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('• Пароли хранятся в захэшированном виде'),
                Text('• Защита от brute force атак'),
                Text('• Валидация входных данных'),
                Text('• Логирование security events'),
                SizedBox(height: 10),
                Text('Тестовые пароли соответствуют политике безопасности'),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Закрыть'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Герб Екатеринбурга и заголовок
                Column(
                  children: [
                    Container(
                      width: 180,
                      height: 180,
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Image.asset(
                          'assets/images/ekb_gerb.png',
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    Text(
                      'КАБИНЕТ ДЕПУТАТА',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: Theme.of(context).primaryColor,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Екатеринбургская городская Дума',
                      style: TextStyle(
                        fontSize: 16,
                        color: Theme.of(context).hintColor,
                        fontWeight: FontWeight.w500,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
                const SizedBox(height: 40),

                // Поле email
                TextFormField(
                  key: const Key('email_field'),
                  controller: _emailController,
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                  decoration: InputDecoration(
                    labelText: 'Email',
                    labelStyle: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                    prefixIcon: Icon(Icons.email, color: Theme.of(context).colorScheme.onSurface),
                    border: const OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Введите email';
                    }
                    if (!SecurityService.isValidEmail(value)) {
                      return 'Введите корректный email';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Поле пароля
                TextFormField(
                  key: const Key('password_field'),
                  controller: _passwordController,
                  obscureText: _obscurePassword,
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                  decoration: InputDecoration(
                    labelText: 'Пароль',
                    labelStyle: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                    prefixIcon: Icon(Icons.lock, color: Theme.of(context).colorScheme.onSurface),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscurePassword ? Icons.visibility : Icons.visibility_off,
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                      onPressed: () {
                        setState(() {
                          _obscurePassword = !_obscurePassword;
                        });
                      },
                    ),
                    border: const OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Введите пароль';
                    }
                    if (!SecurityService.isValidPassword(value)) {
                      return 'Пароль должен содержать минимум 6 символов';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 24),

                // Кнопка входа
                if (_isLoading)
                  const CircularProgressIndicator()
                else
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _login,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue[700],
                      ),
                      child: const Text(
                        'Войти',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),

                const SizedBox(height: 16),
                TextButton.icon(
                  onPressed: _showSecurityInfo,
                  icon: const Icon(Icons.security, size: 16),
                  label: const Text('Информация о безопасности'),
                  style: TextButton.styleFrom(foregroundColor: Colors.grey[600]),
                ),

                // Тестовые аккаунты с новыми паролями
                const SizedBox(height: 20),
                const Divider(),
                const SizedBox(height: 10),

                const Text(
                  'Тестовые аккаунты:',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('admin@duma-ekb.ru (Админ)',
                        style: TextStyle(color: Colors.grey[600], fontSize: 11)),
                    Text('Пароль: admin123',
                        style: TextStyle(color: Colors.green[600], fontSize: 11, fontWeight: FontWeight.bold)),

                    const SizedBox(height: 6),

                    Text('deputy@duma-ekb.ru (Депутат)',
                        style: TextStyle(color: Colors.grey[600], fontSize: 11)),
                    Text('Пароль: deputy123',
                        style: TextStyle(color: Colors.green[600], fontSize: 11, fontWeight: FontWeight.bold)),

                    const SizedBox(height: 6),

                    Text('staff@duma-ekb.ru (Сотрудник)',
                        style: TextStyle(color: Colors.grey[600], fontSize: 11)),
                    Text('Пароль: staff123',
                        style: TextStyle(color: Colors.green[600], fontSize: 11, fontWeight: FontWeight.bold)),
                  ],
                ),
              ], // Закрытие children Column
            ), // Закрытие Column
          ), // Закрытие Form
        ), // Закрытие Padding
      ), // Закрытие SafeArea
    ); // Закрытие Scaffold
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}