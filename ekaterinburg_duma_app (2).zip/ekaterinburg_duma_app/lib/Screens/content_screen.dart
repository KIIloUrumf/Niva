import 'package:flutter/material.dart';
import '../services/document_service.dart';
import '../models/document_model.dart';
import '../services/event_service.dart';
import '../models/event_attendance_model.dart';

class ContentScreen extends StatefulWidget {
  final String title;
  final Map<String, dynamic> userData;

  const ContentScreen({
    super.key,
    required this.title,
    required this.userData,
  });

  @override
  State<ContentScreen> createState() => _ContentScreenState();
}

class _ContentScreenState extends State<ContentScreen> {
  List<DocumentCategory> _documentCategories = [];
  final Map<String, String> _eventConfirmations = {};
  List<Map<String, dynamic>> _allEvents = [];
  bool _isLoadingEvents = false;

  @override
  void initState() {
    super.initState();
    _loadDocumentCategories();
    _loadEventsFromDB();
    _setupRealTimeUpdates();
  }

  void _setupRealTimeUpdates() {
    // Упрощенная подписка на обновления - используем переименованный метод
    EventService.getInvitationsStream().listen((invitations) {
      // При любом изменении приглашений перезагружаем список
      _loadEventsFromDB();
    });
  }

  String _formatEventDateRussian(DateTime dateTime) {
    final months = [
      'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
      'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
    ];

    final weekdays = [
      'Понедельник', 'Вторник', 'Среда', 'Четверг',
      'Пятница', 'Суббота', 'Воскресенье'
    ];

    return '${weekdays[dateTime.weekday - 1]}, '
        '${dateTime.day} ${months[dateTime.month - 1]} ${dateTime.year} '
        'в ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _loadEventsFromDB() async {
    setState(() => _isLoadingEvents = true);
    try {
      final events = await EventService.getSimpleEvents();

      // Для каждого события получаем количество подтверждений
      final eventsWithConfirmations = await Future.wait(
          events.map((event) async {
            final confirmedCount = await EventService.getConfirmedCount(event['id']);
            return {
              ...event,
              'date': _formatEventDateRussian(DateTime.parse(event['date_time'])),
              'confirmed_count': confirmedCount,
            };
          })
      );

      setState(() {
        _allEvents = eventsWithConfirmations;
      });
    } catch (e) {
      print('Error loading events from DB: $e');
    } finally {
      setState(() => _isLoadingEvents = false);
    }
  }

  Future<void> _loadDocumentCategories() async {
    final categories = await DocumentService.getDocumentCategories();
    setState(() => _documentCategories = categories);
  }

  final List<Map<String, dynamic>> _documents = [
    {
      'id': 'doc1',
      'title': 'Протокол заседания №45 от 15.12.2025',
      'categoryId': '2',
      'fileName': 'protocol_45.pdf',
      'fileSize': 2450000,
      'uploadDate': '2025-12-15',
      'uploadedBy': 'Иван Иванов',
      'type': 'pdf',
    },
    {
      'id': 'doc2',
      'title': 'Бюджет города на 2025 год',
      'categoryId': '3',
      'fileName': 'budget_2025.pdf',
      'fileSize': 3560000,
      'uploadDate': '2025-12-10',
      'uploadedBy': 'Петр Петров',
      'type': 'pdf',
    },
    {
      'id': 'doc3',
      'title': 'Отчет о работе комиссии по образованию',
      'categoryId': '4',
      'fileName': 'education_report.docx',
      'fileSize': 1200000,
      'uploadDate': '2025-12-08',
      'uploadedBy': 'Мария Сидорова',
      'type': 'docx',
    },
  ];

  final List<Map<String, dynamic>> _eventsWithAttendance = [
    {
      'id': 'event1',
      'title': 'Заседание комитета по бюджету',
      'date': '20.12.2025 10:00',
      'location': 'Зал заседаний №1',
      'totalInvited': 15,
      'confirmed': 12,
      'attended': 10,
      'attendanceRate': 66.7,
      'minAttendance': 8,
      'canProceed': true,
      'status': 'completed',
    },
    {
      'id': 'event2',
      'title': 'Встреча с избирателями',
      'date': '21.12.2025 14:00',
      'location': 'Центральный округ',
      'totalInvited': 25,
      'confirmed': 18,
      'attended': 0,
      'attendanceRate': 0.0,
      'minAttendance': 10,
      'canProceed': false,
      'status': 'upcoming',
    },
    {
      'id': 'event3',
      'title': 'Пленарное заседание',
      'date': '23.12.2025 09:00',
      'location': 'Большой зал заседаний',
      'totalInvited': 45,
      'confirmed': 38,
      'attended': 0,
      'attendanceRate': 0.0,
      'minAttendance': 23,
      'canProceed': true,
      'status': 'upcoming',
    },
  ];

  Map<String, dynamic> _getContentData() {
    switch (widget.title) {
      case 'Документы':
        return {
          'Последние документы': [
            'Протокол заседания №45 от 15.12.2025',
            'Бюджет города на 2025 год',
            'Отчет о работе комиссии по образованию',
            'План мероприятий на январь 2026',
            'Решение о благоустройстве парков'
          ],
          'Категории': ['Законы', 'Постановления', 'Отчеты', 'Планы']
        };

      case 'Мероприятия':
        final allEvents = [
          ..._allEvents,
          {
            'title': 'Заседание комитета по бюджету',
            'date': '20.12.2025 10:00',
            'location': 'Зал заседаний №1',
            'id': 'event1',
            'status': 'scheduled'
          },
          {
            'title': 'Встреча с избирателями',
            'date': '21.12.2025 14:00',
            'location': 'Центральный округ',
            'id': 'event2',
            'status': 'scheduled'
          },
        ];

        return {
          'Текущие мероприятия': allEvents
        };

      case 'Расписание':
        return {
          'Ближайшие мероприятия': [
            '10:00 - Заседание комитета по бюджету',
            '14:00 - Встреча с избирателями',
            '16:30 - Совещание по транспортной реформе',
            '09:00 - Прием граждан (еженедельно)',
            '11:00 - Работа с документами'
          ],
          'На этой неделе': [
            'Понедельник: 3 мероприятия',
            'Вторник: 2 мероприятия',
            'Среда: 4 мероприятия'
          ]
        };

      case 'Заседания':
        return {
          'Предстоящие заседания': [
            '20.12.2025 - Пленарное заседание',
            '25.12.2025 - Комиссия по ЖКХ',
            '28.12.2025 - Итоговое заседание года'
          ],
          'Архив': [
            'Ноябрь 2025: 5 заседаний',
            'Октябрь 2025: 4 заседания'
          ]
        };

      case 'Обращения':
        return {
          'Новые обращения': [
            'Иванов А.П. - вопрос о ремонте дорог',
            'Петрова С.И. - проблема с вывозом мусора',
            'Сидоров В.М. - предложение по благоустройству'
          ],
          'Статусы': [
            'На рассмотрении: 12',
            'Решено: 45',
            'В работе: 8'
          ]
        };

      case 'Комиссии':
        return {
          'Ваши комиссии': [
            'Комиссия по бюджету и налогам',
            'Комиссия по социальной политике',
            'Комиссия по градостроительству'
          ],
          'Ближайшие заседания': [
            'Комиссия по бюджету - завтра',
            'Социальная политика - через 3 дня'
          ]
        };

      case 'Профиль':
        return {
          'Личная информация': [
            'ФИО: ${widget.userData['name']}',
            'Должность: ${widget.userData['position']}',
            'Роль: ${widget.userData['role'] == 'deputy' ? 'Депутат' : widget.userData['role'] == 'admin' ? 'Администратор' : 'Сотрудник'}',
            'Email: ${widget.userData['email']}',
            'Телефон: ${widget.userData['phone'] ?? 'Не указан'}'
          ],
          'Статистика': [
            'Обработано документов: 156',
            'Участие в заседаниях: 89%',
            'Создано мероприятий: ${_allEvents.length}'
          ]
        };

      case 'Явка':
        return {
          'Статистика посещаемости': [
            'Общая явка: 78%',
            'Заседания комитетов: 85%',
            'Пленарные заседания: 92%',
            'Встречи с избирателями: 65%'
          ]
        };

      default:
        return {
          'Информация': [
            'Раздел "${widget.title}" в разработке',
            'Скоро здесь появится полезный контент',
            'Для связи: support@duma-ekb.ru'
          ]
        };
    }
  }

  void _confirmAttendance(String eventId, String status) async {
    try {
      await EventService.confirmAttendance(eventId, status);

      setState(() {
        _eventConfirmations[eventId] = status;
      });

      // Обновляем счетчик
      await _loadEventsFromDB();

      String statusText = status == 'yes' ? 'присутствую' : 'отсутствую';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Вы подтвердили: $statusText')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка подтверждения: $e')),
      );
    }
  }

  Widget _buildEventCard(Map<String, dynamic> event) {
    final eventId = event['id']!;
    final currentStatus = _eventConfirmations[eventId];
    final confirmedCount = event['confirmed_count'] ?? 0;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              event['title'],
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),

            // Счетчик подтверждений
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.green[50],
                border: Border.all(color: Colors.green),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.people, size: 16, color: Colors.green[700]),
                  const SizedBox(width: 4),
                  Text(
                    '$confirmedCount человек уже подтвердили',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.green[700],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.calendar_today, size: 16, color: Colors.grey[600]),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    event['date'],
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.location_on, size: 16, color: Colors.grey[600]),
                const SizedBox(width: 4),
                Text(event['location'], style: TextStyle(color: Colors.grey[600])),
              ],
            ),
            const SizedBox(height: 12),

            if (currentStatus == null) ...[
              const Text('Подтвердите участие:', style: TextStyle(fontSize: 14)),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _confirmAttendance(eventId, 'yes'),
                      icon: const Icon(Icons.check, color: Colors.green),
                      label: const Text('Приду', style: TextStyle(color: Colors.green)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _confirmAttendance(eventId, 'no'),
                      icon: const Icon(Icons.close, color: Colors.red),
                      label: const Text('Не приду', style: TextStyle(color: Colors.red)),
                    ),
                  ),
                ],
              ),
            ] else ...[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: currentStatus == 'yes' ? Colors.green[50] : Colors.red[50],
                  border: Border.all(
                    color: currentStatus == 'yes' ? Colors.green : Colors.red,
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      currentStatus == 'yes' ? Icons.check : Icons.close,
                      color: currentStatus == 'yes' ? Colors.green : Colors.red,
                      size: 16,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      currentStatus == 'yes' ? 'Вы присутствуете' : 'Вы отсутствуете',
                      style: TextStyle(
                        color: currentStatus == 'yes' ? Colors.green : Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDocumentsContent() {
    return Column(
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Система документов',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Каталогизированное хранение документов',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                if (widget.userData['role'] == 'admin')
                  IconButton(
                    icon: const Icon(Icons.add_circle_outline),
                    onPressed: _showAddCategoryDialog,
                    tooltip: 'Добавить каталог',
                  ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 16),

        Expanded(
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.2,
            ),
            padding: const EdgeInsets.all(16),
            itemCount: _documentCategories.length,
            itemBuilder: (context, index) {
              final category = _documentCategories[index];
              return _buildCategoryCard(category);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildCategoryCard(DocumentCategory category) {
    IconData getIconFromString(String iconName) {
      switch (iconName) {
        case 'gavel': return Icons.gavel;
        case 'article': return Icons.article;
        case 'attach_money': return Icons.attach_money;
        case 'assessment': return Icons.assessment;
        case 'event': return Icons.event;
        default: return Icons.folder;
      }
    }

    Color getColorFromString(String colorName) {
      switch (colorName) {
        case 'blue': return Colors.blue;
        case 'green': return Colors.green;
        case 'orange': return Colors.orange;
        case 'purple': return Colors.purple;
        case 'red': return Colors.red;
        default: return Colors.blue;
      }
    }

    return Card(
      elevation: 2,
      child: InkWell(
        onTap: () => _showCategoryDocuments(category),
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                getIconFromString(category.icon),
                size: 32,
                color: getColorFromString(category.color),
              ),
              const SizedBox(height: 8),
              Text(
                category.name,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Text(
                '${category.documentCount} документов',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCategoryDocuments(DocumentCategory category) {
    final categoryDocs = _documents.where((doc) => doc['categoryId'] == category.id).toList();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.8,
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  category.name,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: categoryDocs.isEmpty
                  ? const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.folder_open, size: 64, color: Colors.grey),
                    SizedBox(height: 16),
                    Text('В этом каталоге пока нет документов'),
                  ],
                ),
              )
                  : ListView.builder(
                itemCount: categoryDocs.length,
                itemBuilder: (context, index) {
                  final doc = categoryDocs[index];
                  return _buildDocumentItem(doc);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDocumentItem(Map<String, dynamic> document) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: Icon(
          _getDocumentIcon(document['type']),
          color: Colors.blue[700],
        ),
        title: Text(document['title']),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${_formatFileSize(document['fileSize'])} • ${document['uploadDate']}'),
            Text('Загрузил: ${document['uploadedBy']}', style: const TextStyle(fontSize: 12)),
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.download),
          onPressed: () => _downloadDocument(document),
        ),
        onTap: () => _showDocumentDetails(document),
      ),
    );
  }

  IconData _getDocumentIcon(String? type) {
    switch (type) {
      case 'pdf': return Icons.picture_as_pdf;
      case 'docx': return Icons.description;
      default: return Icons.insert_drive_file;
    }
  }

  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes Б';
    if (bytes < 1048576) return '${(bytes / 1024).toStringAsFixed(1)} КБ';
    return '${(bytes / 1048576).toStringAsFixed(1)} МБ';
  }

  void _downloadDocument(Map<String, dynamic> document) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Загрузка: ${document['title']}'),
        action: SnackBarAction(
          label: 'Открыть',
          onPressed: () {},
        ),
      ),
    );
  }

  void _showDocumentDetails(Map<String, dynamic> document) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(document['title']),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildDetailItem('Размер файла', _formatFileSize(document['fileSize'])),
              _buildDetailItem('Дата загрузки', document['uploadDate']),
              _buildDetailItem('Загрузил', document['uploadedBy']),
              _buildDetailItem('Тип файла', document['type']?.toUpperCase() ?? 'Файл'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Закрыть'),
          ),
          ElevatedButton(
            onPressed: () => _downloadDocument(document),
            child: const Text('Скачать'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailItem(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Text('$title: ', style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(value),
        ],
      ),
    );
  }

  void _showAddCategoryDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Добавить каталог'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Функционал добавления каталогов в разработке'),
            SizedBox(height: 16),
            Text('В следующем обновлении появится возможность создавать новые каталоги документов.'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Закрыть'),
          ),
        ],
      ),
    );
  }

  Widget _buildAttendanceCRM() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Мониторинг явки на мероприятия',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Отслеживание посещаемости в реальном времени',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildAttendanceStat('Всего мероприятий', _eventsWithAttendance.length),
                      _buildAttendanceStat('Состоялось', _eventsWithAttendance.where((e) => e['status'] == 'completed').length),
                      _buildAttendanceStat('Предстоит', _eventsWithAttendance.where((e) => e['status'] == 'upcoming').length),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          const Text(
            'Мероприятия и явка',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          ..._eventsWithAttendance.map((event) => _buildAttendanceEventCard(event)),
        ],
      ),
    );
  }

  Widget _buildAttendanceStat(String title, int count) {
    return Column(
      children: [
        Text(
          count.toString(),
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.blue,
          ),
        ),
        Text(
          title,
          style: const TextStyle(fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildAttendanceEventCard(Map<String, dynamic> event) {
    final attendanceRate = event['attendanceRate'];
    final canProceed = event['canProceed'];
    final status = event['status'];

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    event['title'],
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: status == 'completed' ? Colors.green[100] : Colors.blue[100],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    status == 'completed' ? 'Завершено' : 'Предстоит',
                    style: TextStyle(
                      fontSize: 12,
                      color: status == 'completed' ? Colors.green[800] : Colors.blue[800],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.calendar_today, size: 16, color: Colors.grey[600]),
                const SizedBox(width: 4),
                Text(event['date'], style: TextStyle(color: Colors.grey[600])),
                const SizedBox(width: 16),
                Icon(Icons.location_on, size: 16, color: Colors.grey[600]),
                const SizedBox(width: 4),
                Text(event['location'], style: TextStyle(color: Colors.grey[600])),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                _buildAttendanceMetric('Приглашено', event['totalInvited'].toString()),
                _buildAttendanceMetric('Подтвердили', event['confirmed'].toString()),
                _buildAttendanceMetric('Присутствовало', event['attended'].toString()),
              ],
            ),
            const SizedBox(height: 8),

            LinearProgressIndicator(
              value: (attendanceRate as int) / 100.0,
              backgroundColor: Colors.grey[300],
              valueColor: AlwaysStoppedAnimation<Color>(
                attendanceRate >= 50 ? Colors.green : Colors.orange,
              ),
            ),
            const SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Явка: ${attendanceRate.toStringAsFixed(1)}%',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: attendanceRate >= 50 ? Colors.green : Colors.orange,
                  ),
                ),
                Text(
                  'Минимум: ${event['minAttendance']} чел.',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),

            if (status == 'upcoming') ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: canProceed ? Colors.green[50] : Colors.red[50],
                  border: Border.all(
                    color: canProceed ? Colors.green : Colors.red,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(
                      canProceed ? Icons.check_circle : Icons.warning,
                      color: canProceed ? Colors.green : Colors.red,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        canProceed
                            ? 'Мероприятие может состояться (явка достаточная)'
                            : 'ВНИМАНИЕ: Мероприятие под угрозой срыва (явка недостаточная)',
                        style: TextStyle(
                          color: canProceed ? Colors.green[800] : Colors.red[800],
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildAttendanceMetric(String title, String value) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            title,
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildEventsContent(Map<String, dynamic> contentData) {
    final canCreateEvent = widget.userData['role'] == 'deputy' || widget.userData['role'] == 'admin';

    if (_isLoadingEvents) {
      return const Center(child: CircularProgressIndicator());
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Подтверждение участия в мероприятиях',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Пожалуйста, подтвердите ваше участие в предстоящих мероприятиях',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (canCreateEvent)
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline, size: 32),
                          onPressed: _showCreateEventDialog,
                          tooltip: 'Создать мероприятие',
                          color: Colors.blue[700],
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          ...contentData.entries.map((entry) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.key,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                ...(entry.value as List).map((event) {
                  return _buildEventCard(event);
                }),
                const SizedBox(height: 20),
              ],
            );
          }),
        ],
      ),
    );
  }

  void _showCreateEventDialog() {
    String title = '';
    String description = '';
    DateTime selectedDate = DateTime.now().add(const Duration(days: 1));
    TimeOfDay selectedTime = const TimeOfDay(hour: 10, minute: 0);
    String location = '';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text('Создать мероприятие'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    decoration: const InputDecoration(
                      labelText: 'Название мероприятия',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (value) => title = value,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    decoration: const InputDecoration(
                      labelText: 'Описание',
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 3,
                    onChanged: (value) => description = value,
                  ),
                  const SizedBox(height: 12),

                  // Русский стиль выбора даты и времени
                  const Text('Дата и время:', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),

                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () async {
                            final date = await showDatePicker(
                              context: context,
                              initialDate: selectedDate,
                              firstDate: DateTime.now(),
                              lastDate: DateTime.now().add(const Duration(days: 365)),
                              locale: const Locale('ru', 'RU'), // Русская локализация
                            );
                            if (date != null) {
                              setDialogState(() {
                                selectedDate = date;
                              });
                            }
                          },
                          child: Text(
                            '${selectedDate.day.toString().padLeft(2, '0')}.${selectedDate.month.toString().padLeft(2, '0')}.${selectedDate.year}',
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () async {
                            final time = await showTimePicker(
                              context: context,
                              initialTime: selectedTime,
                              builder: (BuildContext context, Widget? child) {
                                return Localizations.override(
                                  context: context,
                                  locale: const Locale('ru', 'RU'),
                                  child: child,
                                );
                              },
                            );
                            if (time != null) {
                              setDialogState(() {
                                selectedTime = time;
                              });
                            }
                          },
                          child: Text(
                            '${selectedTime.hour.toString().padLeft(2, '0')}:${selectedTime.minute.toString().padLeft(2, '0')}',
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),
                  TextField(
                    decoration: const InputDecoration(
                      labelText: 'Место проведения',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (value) => location = value,
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Отмена'),
              ),
              ElevatedButton(
                onPressed: () => _createEvent(
                  title,
                  description,
                  DateTime(
                    selectedDate.year,
                    selectedDate.month,
                    selectedDate.day,
                    selectedTime.hour,
                    selectedTime.minute,
                  ),
                  location,
                ),
                child: const Text('Создать'),
              ),
            ],
          );
        },
      ),
    );
  }

  void _createEvent(String title, String description, DateTime dateTime, String location) async {
    if (title.isEmpty || location.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Заполните название и место проведения')),
      );
      return;
    }

    try {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Создание мероприятия...')),
      );

      final newEventData = await EventService.createSimpleEvent(
        title: title,
        description: description,
        dateTime: dateTime,
        location: location,
      );

      await _loadEventsFromDB();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Мероприятие "$title" успешно создано!')),
      );

      Navigator.pop(context);

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Ошибка создания: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Widget _buildContentByTitle(Map<String, dynamic> contentData) {
    switch (widget.title) {
      case 'Документы':
        return _buildDocumentsContent();
      case 'Мероприятия':
        return _buildEventsContent(contentData);
      case 'Явка':
        return _buildAttendanceCRM();
      default:
        return _buildDefaultContent(contentData);
    }
  }

  Widget _buildDefaultContent(Map<String, dynamic> contentData) {
    return ListView(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Добро пожаловать в раздел "${widget.title}"',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Здесь вы можете управлять всеми данными, связанными с ${widget.title}',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              ...contentData.entries.map((entry) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      entry.key,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...(entry.value as List).map((item) {
                      if (item is String) {
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          child: ListTile(
                            leading: const Icon(Icons.circle, size: 8),
                            title: Text(item),
                            onTap: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Выбрано: $item')),
                              );
                            },
                          ),
                        );
                      } else {
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          child: ListTile(
                            leading: const Icon(Icons.circle, size: 8),
                            title: Text(item['title']),
                            onTap: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Выбрано: ${item['title']}')),
                              );
                            },
                          ),
                        );
                      }
                    }),
                    const SizedBox(height: 20),
                  ],
                );
              }),
            ],
          ),
        ),
      ],
    );
  }

  void _showDocumentsStats() {
    final totalDocuments = _documents.length;
    final totalSize = _documents.fold(0, (int sum, doc) => sum + (doc['fileSize'] as int));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Статистика документов'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDocumentsStatItem('Всего документов', totalDocuments.toString()),
            _buildDocumentsStatItem('Общий размер', _formatFileSize(totalSize)),
            _buildDocumentsStatItem('Каталогов', _documentCategories.length.toString()),
            const SizedBox(height: 16),
            const Text(
              'Распределение по каталогам:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            ..._documentCategories.map((category) {
              final count = _documents.where((doc) => doc['categoryId'] == category.id).length;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 2.0),
                child: Text('• ${category.name}: $count документов'),
              );
            }),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Закрыть'),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentsStatItem(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final contentData = _getContentData();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Colors.blue[700],
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          if (widget.title == 'Мероприятия')
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: _loadEventsFromDB,
              tooltip: 'Обновить мероприятия',
            ),
          if (widget.title == 'Документы' && widget.userData['role'] == 'admin')
            IconButton(
              icon: const Icon(Icons.bar_chart),
              onPressed: _showDocumentsStats,
            ),
        ],
      ),
      body: _buildContentByTitle(contentData),
    );
  }
}