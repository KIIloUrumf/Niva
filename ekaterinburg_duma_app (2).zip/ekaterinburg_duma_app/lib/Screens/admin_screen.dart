import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/supabase_service.dart';
import '../main.dart';
import '../screens/main_menu_screen.dart';
import '../config/supabase_config.dart';

class AdminScreen extends StatefulWidget {
  final Map<String, dynamic> userData;

  const AdminScreen({super.key, required this.userData});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  List<Map<String, dynamic>> _allUsers = [];
  bool _isLoading = true;

  final List<String> _availableRoles = ['admin', 'deputy', 'staff'];
  final List<String> _availablePermissions = [
    'events', 'documents', 'meetings', 'feedback', 'admin', 'all'
  ];

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    try {
      final response = await SupabaseService.client
          .from('users')
          .select()
          .order('created_at', ascending: false);

      setState(() {
        _allUsers = (response as List).cast<Map<String, dynamic>>();
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading users: $e');
      setState(() => _isLoading = false);
    }
  }

  void _showCreateUserDialog() {
    String name = '';
    String email = '';
    String password = '';
    String role = 'staff';
    List<String> permissions = [];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text('Создать пользователя'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    decoration: const InputDecoration(labelText: 'ФИО'),
                    onChanged: (value) => name = value,
                  ),
                  TextField(
                    decoration: const InputDecoration(labelText: 'Email'),
                    onChanged: (value) => email = value,
                  ),
                  TextField(
                    decoration: const InputDecoration(labelText: 'Пароль'),
                    obscureText: true,
                    onChanged: (value) => password = value,
                  ),
                  const SizedBox(height: 16),
                  const Text('Роль:', style: TextStyle(fontWeight: FontWeight.bold)),
                  DropdownButton<String>(
                    value: role,
                    onChanged: (value) => setDialogState(() => role = value!),
                    items: _availableRoles.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(_getRoleDisplayName(value)),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Отмена'),
              ),
              ElevatedButton(
                onPressed: () => _createUser(name, email, password, role, permissions),
                child: const Text('Создать'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _createUser(String name, String email, String password, String role, List<String> permissions) async {
    if (name.isEmpty || email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Заполните все поля')),
      );
      return;
    }

    try {
      // Создаем клиент с service_role для прав админа
      final adminClient = SupabaseClient(
          SupabaseConfig.url,
          SupabaseConfig.serviceRoleKey // Используем service_role
      );

      // Создаем пользователя в Auth
      final authResponse = await adminClient.auth.admin.createUser(
        AdminUserAttributes(
          email: email,
          password: password,
          emailConfirm: true,
        ),
      );

      if (authResponse.user != null) {
        // Добавляем в таблицу users через обычный клиент
        await SupabaseService.client.from('users').insert({
          'id': authResponse.user!.id,
          'email': email,
          'name': name,
          'role': role,
          'position': _getDefaultPosition(role),
          'department': _getDefaultDepartment(role),
          'permissions': _getDefaultPermissions(role),
          'is_active': true,
        });

        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Пользователь $email создан')),
        );

        _loadUsers();
      }
    } catch (e) {
      print('Create user error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка создания: $e')),
      );
    }
  }

  String _getDefaultPosition(String role) {
    switch (role) {
      case 'admin': return 'Администратор';
      case 'deputy': return 'Депутат';
      case 'staff': return 'Сотрудник аппарата';
      default: return 'Сотрудник';
    }
  }

  String _getDefaultDepartment(String role) {
    switch (role) {
      case 'admin': return 'ИТ отдел';
      case 'deputy': return 'Комитет по бюджету';
      case 'staff': return 'Организационный отдел';
      default: return 'Отдел';
    }
  }

  List<String> _getDefaultPermissions(String role) {
    switch (role) {
      case 'admin': return ['all'];
      case 'deputy': return ['events', 'documents', 'profile', 'meetings', 'feedback', 'attendance'];
      case 'staff': return ['documents', 'profile'];
      default: return ['documents', 'profile'];
    }
  }

  void _switchUser(Map<String, dynamic> user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Переключить пользователя'),
        content: Text('Войти как ${user['name']}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Отмена'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (context) => MainMenuScreen(userData: user),
                ),
                    (route) => false,
              );
            },
            child: const Text('Войти'),
          ),
        ],
      ),
    );
  }

  void _editUserPermissions(int index) {
    final user = _allUsers[index];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: Text('Редактирование: ${user['name']}'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildRoleSelector(user, setDialogState),
                  const SizedBox(height: 16),
                  _buildPermissionsSelector(user, setDialogState),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Отмена'),
              ),
              TextButton(
                onPressed: () {
                  _saveUserChanges(index, user);
                  Navigator.pop(context);
                },
                child: const Text('Сохранить'),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildRoleSelector(Map<String, dynamic> user, StateSetter setDialogState) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Роль:', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: _availableRoles.map((role) {
            final isSelected = user['role'] == role;
            return FilterChip(
              label: Text(_getRoleDisplayName(role)),
              selected: isSelected,
              onSelected: (selected) {
                setDialogState(() {
                  user['role'] = role;
                });
              },
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildPermissionsSelector(Map<String, dynamic> user, StateSetter setDialogState) {
    final permissions = List<String>.from(user['permissions'] ?? []);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Права доступа:', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: _availablePermissions.map((permission) {
            final isSelected = permissions.contains(permission);
            return FilterChip(
              label: Text(_getPermissionDisplayName(permission)),
              selected: isSelected,
              onSelected: (selected) {
                setDialogState(() {
                  if (selected) {
                    if (!permissions.contains(permission)) {
                      permissions.add(permission);
                    }
                  } else {
                    permissions.remove(permission);
                  }
                  user['permissions'] = permissions;
                });
              },
            );
          }).toList(),
        ),
      ],
    );
  }

  String _getRoleDisplayName(String role) {
    switch (role) {
      case 'admin': return 'Администратор';
      case 'deputy': return 'Депутат';
      case 'staff': return 'Сотрудник';
      default: return role;
    }
  }

  String _getPermissionDisplayName(String permission) {
    switch (permission) {
      case 'events': return 'Мероприятия';
      case 'documents': return 'Документы';
      case 'meetings': return 'Заседания';
      case 'feedback': return 'Обращения';
      case 'admin': return 'Администрирование';
      case 'all': return 'Все права';
      default: return permission;
    }
  }

  void _saveUserChanges(int index, Map<String, dynamic> updatedUser) async {
    try {
      await SupabaseService.client
          .from('users')
          .update({
        'role': updatedUser['role'],
        'permissions': updatedUser['permissions'],
      })
          .eq('id', updatedUser['id']);

      setState(() {
        _allUsers[index] = {..._allUsers[index], ...updatedUser};
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Права пользователя ${updatedUser['name']} обновлены')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка обновления: $e')),
      );
    }
  }

  void _toggleUserStatus(int index) async {
    final user = _allUsers[index];
    final newStatus = !(user['is_active'] == true);

    try {
      final response = await SupabaseService.client
          .from('users')
          .update({'is_active': newStatus})
          .eq('id', user['id'])
          .select();

      print('Toggle status response: $response');

      setState(() {
        _allUsers[index]['is_active'] = newStatus;
      });

      final status = newStatus ? 'активирован' : 'деактивирован';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Пользователь ${user['name']} $status')),
      );

      // Перезагружаем список чтобы убедиться
      _loadUsers();
    } catch (e) {
      print('Toggle status error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка обновления: $e')),
      );
    }
  }

  void _showUserStats() {
    final activeUsers = _allUsers.where((user) => user['is_active'] == true).length;
    final deputies = _allUsers.where((user) => user['role'] == 'deputy').length;
    final staff = _allUsers.where((user) => user['role'] == 'staff').length;
    final admins = _allUsers.where((user) => user['role'] == 'admin').length;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Статистика пользователей'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildStatItem('Всего пользователей', _allUsers.length.toString()),
            _buildStatItem('Активных пользователей', activeUsers.toString()),
            _buildStatItem('Депутатов', deputies.toString()),
            _buildStatItem('Сотрудников', staff.toString()),
            _buildStatItem('Администраторов', admins.toString()),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Закрыть'),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Администрирование'),
        backgroundColor: Colors.deepPurple,
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add),
            onPressed: _showCreateUserDialog,
            tooltip: 'Создать пользователя',
          ),
          IconButton(
            icon: const Icon(Icons.analytics),
            onPressed: _showUserStats,
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadUsers,
            tooltip: 'Обновить список',
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
        children: [
          Card(
            margin: const EdgeInsets.all(16),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildAdminStat('Пользователи', _allUsers.length),
                  _buildAdminStat('Активные', _allUsers.where((u) => u['is_active'] == true).length),
                  _buildAdminStat('Депутаты', _allUsers.where((u) => u['role'] == 'deputy').length),
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _allUsers.length,
              itemBuilder: (context, index) {
                final user = _allUsers[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: user['is_active'] == true ? Colors.green : Colors.grey,
                      child: Text(
                        user['name'].toString().substring(0, 2),
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                    title: Text(user['name']),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${user['position']} • ${user['department']}'),
                        Text(user['email'], style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 4),
                        Wrap(
                          spacing: 4,
                          children: [
                            Chip(
                              label: Text(
                                _getRoleDisplayName(user['role']),
                                style: const TextStyle(fontSize: 10),
                              ),
                              backgroundColor: Colors.blue[50],
                            ),
                            if (user['permissions'] != null)
                              ...(user['permissions'] as List).map<Widget>((perm) => Chip(
                                label: Text(
                                  _getPermissionDisplayName(perm.toString()),
                                  style: const TextStyle(fontSize: 10),
                                ),
                                backgroundColor: Colors.green[50],
                              )).toList(),
                          ],
                        ),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.switch_account, size: 20),
                          onPressed: () => _switchUser(user),
                          tooltip: 'Переключиться',
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit, size: 20),
                          onPressed: () => _editUserPermissions(index),
                        ),
                        IconButton(
                          icon: Icon(
                            user['is_active'] == true ? Icons.toggle_on : Icons.toggle_off,
                            color: user['is_active'] == true ? Colors.green : Colors.grey,
                            size: 30,
                          ),
                          onPressed: () => _toggleUserStatus(index),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAdminStat(String title, int count) {
    return Column(
      children: [
        Text(
          count.toString(),
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    );
  }
}