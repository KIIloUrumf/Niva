class DocumentCategory {
  final String id;
  final String name;
  final String? parentId;
  final int documentCount;
  final String color;
  final String icon;

  DocumentCategory({
    required this.id,
    required this.name,
    this.parentId,
    this.documentCount = 0,
    this.color = '4285F4', // синий по умолчанию
    this.icon = 'folder',
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'parentId': parentId,
      'documentCount': documentCount,
      'color': color,
      'icon': icon,
    };
  }

  factory DocumentCategory.fromJson(Map<String, dynamic> json) {
    return DocumentCategory(
      id: json['id'],
      name: json['name'],
      parentId: json['parentId'],
      documentCount: json['documentCount'] ?? 0,
      color: json['color'] ?? '4285F4',
      icon: json['icon'] ?? 'folder',
    );
  }
}

class Document {
  final String id;
  final String title;
  final String categoryId;
  final String fileName;
  final int fileSize;
  final DateTime uploadDate;
  final String uploadedBy;
  final String fileType;
  final String? description;
  final String? tags;
  final bool isConfidential;

  Document({
    required this.id,
    required this.title,
    required this.categoryId,
    required this.fileName,
    required this.fileSize,
    required this.uploadDate,
    required this.uploadedBy,
    this.fileType = 'pdf',
    this.description,
    this.tags,
    this.isConfidential = false,
  });

  String get fileExtension {
    return fileType.toLowerCase();
  }

  String get formattedFileSize {
    if (fileSize < 1024) return '$fileSize Б';
    if (fileSize < 1048576) return '${(fileSize / 1024).toStringAsFixed(1)} КБ';
    return '${(fileSize / 1048576).toStringAsFixed(1)} МБ';
  }

  String get formattedUploadDate {
    return '${uploadDate.day.toString().padLeft(2, '0')}.${uploadDate.month.toString().padLeft(2, '0')}.${uploadDate.year}';
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'categoryId': categoryId,
      'fileName': fileName,
      'fileSize': fileSize,
      'uploadDate': uploadDate.toIso8601String(),
      'uploadedBy': uploadedBy,
      'fileType': fileType,
      'description': description,
      'tags': tags,
      'isConfidential': isConfidential,
    };
  }

  factory Document.fromJson(Map<String, dynamic> json) {
    return Document(
      id: json['id'],
      title: json['title'],
      categoryId: json['categoryId'],
      fileName: json['fileName'],
      fileSize: json['fileSize'],
      uploadDate: DateTime.parse(json['uploadDate']),
      uploadedBy: json['uploadedBy'],
      fileType: json['fileType'] ?? 'pdf',
      description: json['description'],
      tags: json['tags'],
      isConfidential: json['isConfidential'] ?? false,
    );
  }
}

class DocumentSearchFilters {
  final String? categoryId;
  final String? query;
  final DateTime? startDate;
  final DateTime? endDate;
  final String? uploadedBy;
  final bool? confidentialOnly;

  DocumentSearchFilters({
    this.categoryId,
    this.query,
    this.startDate,
    this.endDate,
    this.uploadedBy,
    this.confidentialOnly,
  });

  Map<String, dynamic> toJson() {
    return {
      'categoryId': categoryId,
      'query': query,
      'startDate': startDate?.toIso8601String(),
      'endDate': endDate?.toIso8601String(),
      'uploadedBy': uploadedBy,
      'confidentialOnly': confidentialOnly,
    };
  }
}