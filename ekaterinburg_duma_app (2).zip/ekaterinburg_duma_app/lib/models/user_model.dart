class User {
  final String id;
  final String email;
  final String name;
  final String role;
  final String? position;
  final String? department;
  final List<String> permissions;
  final bool isActive;
  final DateTime? lastLogin;

  User({
    required this.id,
    required this.email,
    required this.name,
    required this.role,
    this.position,
    this.department,
    required this.permissions,
    required this.isActive,
    this.lastLogin,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      email: json['email'],
      name: json['name'],
      role: json['role'],
      position: json['position'],
      department: json['department'],
      permissions: List<String>.from(json['permissions'] ?? []),
      isActive: json['is_active'] ?? true,
      lastLogin: json['last_login'] != null
          ? DateTime.parse(json['last_login'])
          : null,
    );
  }
}