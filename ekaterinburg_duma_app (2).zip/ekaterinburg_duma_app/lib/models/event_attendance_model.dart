class Event {
  final String id;
  final String title;
  final String description;
  final DateTime dateTime;
  final String location;
  final String organizer;
  final List<String> invitedUserIds;
  final int minAttendance;
  final String status; // 'scheduled', 'ongoing', 'completed', 'cancelled'
  final String? meetingLink;
  final List<String> tags;

  Event({
    required this.id,
    required this.title,
    required this.description,
    required this.dateTime,
    required this.location,
    required this.organizer,
    required this.invitedUserIds,
    required this.minAttendance,
    this.status = 'scheduled',
    this.meetingLink,
    this.tags = const [],
  });

  String get formattedDate {
    return '${dateTime.day.toString().padLeft(2, '0')}.${dateTime.month.toString().padLeft(2, '0')}.${dateTime.year} ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  bool get isUpcoming {
    return dateTime.isAfter(DateTime.now()) && status == 'scheduled';
  }

  bool get canBeCancelled {
    return isUpcoming && DateTime.now().difference(dateTime).inHours > 2;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'dateTime': dateTime.toIso8601String(),
      'location': location,
      'organizer': organizer,
      'invitedUserIds': invitedUserIds,
      'minAttendance': minAttendance,
      'status': status,
      'meetingLink': meetingLink,
      'tags': tags,
    };
  }

  factory Event.fromJson(Map<String, dynamic> json) {
    return Event(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      dateTime: DateTime.parse(json['dateTime']),
      location: json['location'],
      organizer: json['organizer'],
      invitedUserIds: List<String>.from(json['invitedUserIds']),
      minAttendance: json['minAttendance'],
      status: json['status'] ?? 'scheduled',
      meetingLink: json['meetingLink'],
      tags: List<String>.from(json['tags'] ?? []),
    );
  }
}

class EventAttendance {
  final String id;
  final String eventId;
  final String userId;
  final String userName;
  final String userRole;
  final String status; // 'pending', 'confirmed', 'declined', 'attended', 'absent'
  final DateTime? responseDate;
  final DateTime? checkInTime;
  final DateTime? checkOutTime;
  final String? notes;

  EventAttendance({
    required this.id,
    required this.eventId,
    required this.userId,
    required this.userName,
    required this.userRole,
    this.status = 'pending',
    this.responseDate,
    this.checkInTime,
    this.checkOutTime,
    this.notes,
  });

  bool get hasResponded => status != 'pending';
  bool get isPresent => status == 'attended';
  bool get isConfirmed => status == 'confirmed';
  bool get isAbsent => status == 'absent';

  Duration? get duration {
    if (checkInTime != null && checkOutTime != null) {
      return checkOutTime!.difference(checkInTime!);
    }
    return null;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'eventId': eventId,
      'userId': userId,
      'userName': userName,
      'userRole': userRole,
      'status': status,
      'responseDate': responseDate?.toIso8601String(),
      'checkInTime': checkInTime?.toIso8601String(),
      'checkOutTime': checkOutTime?.toIso8601String(),
      'notes': notes,
    };
  }

  factory EventAttendance.fromJson(Map<String, dynamic> json) {
    return EventAttendance(
      id: json['id'],
      eventId: json['eventId'],
      userId: json['userId'],
      userName: json['userName'],
      userRole: json['userRole'],
      status: json['status'] ?? 'pending',
      responseDate: json['responseDate'] != null ? DateTime.parse(json['responseDate']) : null,
      checkInTime: json['checkInTime'] != null ? DateTime.parse(json['checkInTime']) : null,
      checkOutTime: json['checkOutTime'] != null ? DateTime.parse(json['checkOutTime']) : null,
      notes: json['notes'],
    );
  }
}

class AttendanceReport {
  final String eventId;
  final String eventTitle;
  final DateTime eventDate;
  final int totalInvited;
  final int confirmedCount;
  final int attendedCount;
  final int absentCount;
  final int pendingCount;
  final double attendanceRate;  // изменил num на double
  final double confirmationRate; // изменил num на double
  final bool canProceed;
  final List<EventAttendance> detailedAttendance;

  AttendanceReport({
    required this.eventId,
    required this.eventTitle,
    required this.eventDate,
    required this.totalInvited,
    required this.confirmedCount,
    required this.attendedCount,
    required this.absentCount,
    required this.pendingCount,
    required this.attendanceRate,    // теперь double
    required this.confirmationRate,  // теперь double
    required this.canProceed,
    required this.detailedAttendance,
  });

  int get declinedCount => totalInvited - confirmedCount - pendingCount;

  Map<String, dynamic> toJson() {
    return {
      'eventId': eventId,
      'eventTitle': eventTitle,
      'eventDate': eventDate.toIso8601String(),
      'totalInvited': totalInvited,
      'confirmedCount': confirmedCount,
      'attendedCount': attendedCount,
      'absentCount': absentCount,
      'pendingCount': pendingCount,
      'attendanceRate': attendanceRate,
      'confirmationRate': confirmationRate,
      'canProceed': canProceed,
      'detailedAttendance': detailedAttendance.map((a) => a.toJson()).toList(),
    };
  }

  factory AttendanceReport.generateFromEvent(Event event, List<EventAttendance> attendances) {
    final totalInvited = event.invitedUserIds.length;
    final confirmedCount = attendances.where((a) => a.isConfirmed).length;
    final attendedCount = attendances.where((a) => a.isPresent).length;
    final absentCount = attendances.where((a) => a.isAbsent).length;
    final pendingCount = attendances.where((a) => a.status == 'pending').length;

    final attendanceRate = totalInvited > 0 ? (attendedCount / totalInvited) * 100.0 : 0.0;
    final confirmationRate = totalInvited > 0 ? (confirmedCount / totalInvited) * 100.0 : 0.0;
    final canProceed = confirmedCount >= event.minAttendance;

    return AttendanceReport(
      eventId: event.id,
      eventTitle: event.title,
      eventDate: event.dateTime,
      totalInvited: totalInvited,
      confirmedCount: confirmedCount,
      attendedCount: attendedCount,
      absentCount: absentCount,
      pendingCount: pendingCount,
      attendanceRate: attendanceRate,
      confirmationRate: confirmationRate,
      canProceed: canProceed,
      detailedAttendance: attendances,
    );
  }
}

class RealTimeAttendanceData {
  final String eventId;
  final int currentPresent;
  final int currentAbsent;
  final int expectedTotal;
  final DateTime lastUpdate;
  final bool isEventActive;

  RealTimeAttendanceData({
    required this.eventId,
    required this.currentPresent,
    required this.currentAbsent,
    required this.expectedTotal,
    required this.lastUpdate,
    required this.isEventActive,
  });

  int get currentAttendanceRate {
    return expectedTotal > 0 ? ((currentPresent / expectedTotal) * 100).round() : 0;
  }

  Map<String, dynamic> toJson() {
    return {
      'eventId': eventId,
      'currentPresent': currentPresent,
      'currentAbsent': currentAbsent,
      'expectedTotal': expectedTotal,
      'lastUpdate': lastUpdate.toIso8601String(),
      'isEventActive': isEventActive,
    };
  }
}