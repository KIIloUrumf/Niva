import 'package:flutter_test/flutter_test.dart';
import 'package:duma_ekb_app/services/auth_service.dart';

void main() {
  group('AuthService Static Methods', () {
    test('logout method exists', () {
      expect(AuthService.logout, isA<Future<void> Function()>());
    });

    test('currentUser getter exists', () {
      expect(AuthService.currentUser, isNull);
    });

    test('token getter exists', () {
      expect(AuthService.token, isNull);
    });

    test('resetPassword method exists', () {
      expect(AuthService.resetPassword, isA<Future<void> Function(String)>());
    });
  });
}