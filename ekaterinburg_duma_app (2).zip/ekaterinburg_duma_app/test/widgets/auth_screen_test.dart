import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:duma_ekb_app/screens/auth_screen.dart';

void main() {
  testWidgets('AuthScreen shows login form', (WidgetTester tester) async {
    await tester.pumpWidget(MaterialApp(home: AuthScreen()));

    // Проверяем основные элементы интерфейса
    expect(find.text('КАБИНЕТ ДЕПУТАТА'), findsOneWidget);
    expect(find.text('Екатеринбургская городская Дума'), findsOneWidget);
    expect(find.byType(TextFormField), findsNWidgets(2));
    expect(find.text('Войти'), findsOneWidget);
  });

  testWidgets('AuthScreen has email and password fields', (WidgetTester tester) async {
    await tester.pumpWidget(MaterialApp(home: AuthScreen()));

    expect(find.text('Email'), findsOneWidget);
    expect(find.text('Пароль'), findsOneWidget);
  });
}